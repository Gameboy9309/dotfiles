#!/bin/bash 

echo -e " $(date +%D\ %R) "
