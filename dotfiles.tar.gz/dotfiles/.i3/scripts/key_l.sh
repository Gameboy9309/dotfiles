#!/bin/bash 

Key=$(setxkbmap -query | grep "^layout" | awk '{print $2}')

echo -e " $Key"
